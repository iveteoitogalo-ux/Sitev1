import { neon } from '@neondatabase/serverless';
import { Product } from './supabase';

const sql = neon('postgresql://neondb_owner:npg_V7uyiNm6LXPM@ep-sparkling-math-ac73a4f1-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require');

class ProductCache {
  private products: Product[] = [];
  private lastFetch: number = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000;

  async getProducts(): Promise<Product[]> {
    const now = Date.now();
    if (this.products.length > 0 && now - this.lastFetch < this.CACHE_DURATION) {
      return this.products.filter(p => p.active);
    }

    try {
      const result = await sql`SELECT * FROM produtos WHERE active = true ORDER BY created_at DESC`;
      this.products = result as Product[];
      this.lastFetch = now;
      return this.products;
    } catch (error) {
      console.error('Error fetching products:', error);
      return this.products.filter(p => p.active);
    }
  }

  async getAdminProducts(): Promise<Product[]> {
    try {
      const result = await sql`SELECT * FROM produtos ORDER BY created_at DESC`;
      this.products = result as Product[];
      this.lastFetch = Date.now();
      return this.products;
    } catch (error) {
      console.error('Error fetching admin products:', error);
      return [];
    }
  }

  getProductBySku(sku: string): Product | undefined {
    return this.products.find(p => p.sku === sku);
  }

  updateLocalProduct(product: Product) {
    const index = this.products.findIndex(p => p.id === product.id);
    if (index !== -1) {
      this.products[index] = product;
    } else {
      this.products.push(product);
    }
  }

  removeLocalProduct(id: string) {
    this.products = this.products.filter(p => p.id !== id);
  }

  invalidateCache() {
    this.lastFetch = 0;
  }
}

export const productCache = new ProductCache();

import { neon } from '@neondatabase/serverless';

const sql = neon('postgresql://neondb_owner:npg_V7uyiNm6LXPM@ep-sparkling-math-ac73a4f1-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require');

export interface Product {
  id: string;
  sku: string;
  title: string;
  price: number;
  description: string;
  image_url: string;
  stock: number;
  active: boolean;
  category?: string;
  created_at?: string;
  updated_at?: string;
}

export const supabase = {
  from: (table: string) => ({
    select: (columns: string = '*') => ({
      eq: (column: string, value: any) => ({
        single: async () => {
          try {
            const result = await sql(`SELECT ${columns} FROM ${table} WHERE ${column} = $1 LIMIT 1`, [value]);
            return { data: result[0] || null, error: null };
          } catch (error) {
            return { data: null, error };
          }
        },
        maybeSingle: async () => {
          try {
            const result = await sql(`SELECT ${columns} FROM ${table} WHERE ${column} = $1 LIMIT 1`, [value]);
            return { data: result[0] || null, error: null };
          } catch (error) {
            return { data: null, error };
          }
        }
      }),
      order: (column: string, options?: { ascending: boolean }) => ({
        then: async (resolve: any) => {
          try {
            const order = options?.ascending ? 'ASC' : 'DESC';
            const result = await sql(`SELECT ${columns} FROM ${table} ORDER BY ${column} ${order}`);
            resolve({ data: result, error: null });
          } catch (error) {
            resolve({ data: [], error });
          }
        }
      })
    }),
    insert: (data: any[]) => ({
      select: () => ({
        single: async () => {
          try {
            const keys = Object.keys(data[0]);
            const values = keys.map((_, i) => `$${i + 1}`).join(', ');
            const result = await sql(
              `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${values}) RETURNING *`,
              Object.values(data[0])
            );
            return { data: result[0], error: null };
          } catch (error) {
            return { data: null, error };
          }
        }
      })
    }),
    update: (data: any) => ({
      eq: (column: string, value: any) => ({
        select: () => ({
          single: async () => {
            try {
              const keys = Object.keys(data);
              const sets = keys.map((key, i) => `${key} = $${i + 1}`).join(', ');
              const result = await sql(
                `UPDATE ${table} SET ${sets} WHERE ${column} = $${keys.length + 1} RETURNING *`,
                [...Object.values(data), value]
              );
              return { data: result[0], error: null };
            } catch (error) {
              return { data: null, error };
            }
          }
        })
      })
    }),
    delete: () => ({
      eq: async (column: string, value: any) => {
        try {
          await sql(`DELETE FROM ${table} WHERE ${column} = $1`, [value]);
          return { error: null };
        } catch (error) {
          return { error };
        }
      }
    })
  })
};

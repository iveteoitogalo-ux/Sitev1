# Configuração do Banco de Dados

## 1. Executar Migration SQL

Você precisa executar o script SQL no seu banco de dados Neon para adicionar o campo de categoria aos produtos.

### Opção 1: Via Interface Web do Neon
1. Acesse o dashboard do Neon: https://console.neon.tech/
2. Selecione seu projeto
3. Vá para a aba "SQL Editor"
4. Copie e cole o conteúdo do arquivo `migrations/001_add_category_to_products.sql`
5. Execute o script

### Opção 2: Via psql (Terminal)
```bash
psql 'postgresql://neondb_owner:npg_V7uyiNm6LXPM@ep-sparkling-math-ac73a4f1-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require' -f migrations/001_add_category_to_products.sql
```

## 2. Estrutura da Tabela Produtos

Após a migração, a tabela `produtos` terá a seguinte estrutura:

```sql
- id (serial primary key)
- sku (text) - Código único do produto
- nome / title (text) - Nome do produto
- preco / price (numeric) - Preço do produto
- descricao / description (text) - Descrição do produto
- imagem_url / image_url (text) - URL da imagem
- stock (integer) - Quantidade em estoque
- active (boolean) - Se o produto está ativo
- category (text) - Categoria do produto (dichavador, bong, seda, vaporizador)
- created_at (timestamptz) - Data de criação
- updated_at (timestamptz) - Data de atualização
```

## 3. Categorias Disponíveis

O sistema suporta 4 categorias:
- **dichavador** - Dichavadores ⚙️
- **bong** - Bongs 💨
- **seda** - Sedas 📄
- **vaporizador** - Vaporizadores 🔥

## 4. Funcionalidades Implementadas

### Filtros de Categoria
- Navbar com botões de categoria
- Multi-seleção de categorias
- Filtro dinâmico de produtos
- Botão "Limpar Filtros"

### Painel Admin
- Campo de categoria ao adicionar/editar produtos
- Visualização da categoria de cada produto
- Sistema de gerenciamento de estoque
- Upload de imagens via URL

### Visualização do Produto
- Card otimizado para caber no display sem scroll
- Exibição da categoria do produto
- Design responsivo mobile/desktop

## 5. Próximos Passos (Opcional)

### Upload de Imagens Real
Para implementar upload de imagens real (ao invés de apenas URL), você pode usar:
- Supabase Storage
- Cloudinary
- AWS S3
- ImageKit

### Exemplos de uso:
```typescript
// Adicionar produto com categoria
const newProduct = {
  sku: 'DICH-001',
  title: 'Dichavador Premium',
  price: 45.00,
  description: 'Dichavador de metal com 4 partes',
  image_url: 'https://exemplo.com/imagem.jpg',
  stock: 10,
  active: true,
  category: 'dichavador'
};
```

## 6. Conexão com o Banco

A conexão está configurada em:
- `src/lib/supabase.ts` - Cliente Supabase
- `src/lib/productCache.ts` - Cache de produtos
- `.env` - Variáveis de ambiente

## 7. Observações Importantes

- O nome da tabela no banco é `produtos` (não `products`)
- As categorias são opcionais (produtos sem categoria aparecem em todas as visualizações)
- O cache de produtos é invalidado automaticamente após operações de CRUD
- A navbar de categorias só aparece na página principal (não no admin ou visualização de produto)

/*
  # Setup completo da tabela de produtos

  1. Criação da Tabela
    - Cria tabela `produtos` se não existir
    - Adiciona todas as colunas necessárias

  2. Alterações (se tabela já existe)
    - Adiciona coluna `category` se não existir
    - Adiciona timestamps (created_at, updated_at) se não existirem

  3. Notas
    - A coluna category é opcional (nullable)
    - Produtos sem categoria serão exibidos em todas as visualizações
    - Suporta tanto nomes em português quanto em inglês
*/

-- Criar tabela se não existir
CREATE TABLE IF NOT EXISTS produtos (
  id SERIAL PRIMARY KEY,
  sku TEXT NOT NULL UNIQUE,
  nome TEXT,
  title TEXT,
  preco NUMERIC(10,2),
  price NUMERIC(10,2),
  descricao TEXT,
  description TEXT,
  imagem_url TEXT,
  image_url TEXT,
  stock INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  category TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Adicionar coluna de categoria se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'category'
  ) THEN
    ALTER TABLE produtos ADD COLUMN category TEXT;
  END IF;
END $$;

-- Adicionar stock se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'stock'
  ) THEN
    ALTER TABLE produtos ADD COLUMN stock INTEGER DEFAULT 0;
  END IF;
END $$;

-- Adicionar active se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'active'
  ) THEN
    ALTER TABLE produtos ADD COLUMN active BOOLEAN DEFAULT true;
  END IF;
END $$;

-- Adicionar title se não existir (para compatibilidade)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'title'
  ) THEN
    ALTER TABLE produtos ADD COLUMN title TEXT;
  END IF;
END $$;

-- Adicionar price se não existir (para compatibilidade)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'price'
  ) THEN
    ALTER TABLE produtos ADD COLUMN price NUMERIC(10,2);
  END IF;
END $$;

-- Adicionar description se não existir (para compatibilidade)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'description'
  ) THEN
    ALTER TABLE produtos ADD COLUMN description TEXT;
  END IF;
END $$;

-- Adicionar image_url se não existir (para compatibilidade)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE produtos ADD COLUMN image_url TEXT;
  END IF;
END $$;

-- Adicionar created_at se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'created_at'
  ) THEN
    ALTER TABLE produtos ADD COLUMN created_at TIMESTAMPTZ DEFAULT NOW();
  END IF;
END $$;

-- Adicionar updated_at se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'produtos' AND column_name = 'updated_at'
  ) THEN
    ALTER TABLE produtos ADD COLUMN updated_at TIMESTAMPTZ DEFAULT NOW();
  END IF;
END $$;

-- Criar função para sincronizar campos português/inglês
CREATE OR REPLACE FUNCTION sync_product_fields()
RETURNS TRIGGER AS $$
BEGIN
  -- Sincronizar title/nome
  IF NEW.title IS NOT NULL AND NEW.nome IS NULL THEN
    NEW.nome := NEW.title;
  ELSIF NEW.nome IS NOT NULL AND NEW.title IS NULL THEN
    NEW.title := NEW.nome;
  END IF;

  -- Sincronizar price/preco
  IF NEW.price IS NOT NULL AND NEW.preco IS NULL THEN
    NEW.preco := NEW.price;
  ELSIF NEW.preco IS NOT NULL AND NEW.price IS NULL THEN
    NEW.price := NEW.preco;
  END IF;

  -- Sincronizar description/descricao
  IF NEW.description IS NOT NULL AND NEW.descricao IS NULL THEN
    NEW.descricao := NEW.description;
  ELSIF NEW.descricao IS NOT NULL AND NEW.description IS NULL THEN
    NEW.description := NEW.descricao;
  END IF;

  -- Sincronizar image_url/imagem_url
  IF NEW.image_url IS NOT NULL AND NEW.imagem_url IS NULL THEN
    NEW.imagem_url := NEW.image_url;
  ELSIF NEW.imagem_url IS NOT NULL AND NEW.image_url IS NULL THEN
    NEW.image_url := NEW.imagem_url;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Adicionar trigger para sincronizar campos
DROP TRIGGER IF EXISTS sync_produtos_fields ON produtos;
CREATE TRIGGER sync_produtos_fields
BEFORE INSERT OR UPDATE ON produtos
FOR EACH ROW
EXECUTE FUNCTION sync_product_fields();

-- Adicionar função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Remover trigger se já existir
DROP TRIGGER IF EXISTS update_produtos_updated_at ON produtos;

-- Criar trigger
CREATE TRIGGER update_produtos_updated_at
BEFORE UPDATE ON produtos
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Adicionar constraint para validar categorias (opcional, comentado por enquanto)
-- ALTER TABLE produtos ADD CONSTRAINT check_category
-- CHECK (category IS NULL OR category IN ('dichavador', 'bong', 'seda', 'vaporizador'));

COMMENT ON COLUMN produtos.category IS 'Categoria do produto: dichavador, bong, seda, vaporizador';

-- Inserir alguns produtos de exemplo (opcional - remova se já tem dados)
INSERT INTO produtos (sku, title, price, description, image_url, stock, active, category)
VALUES
  ('DICH-001', 'Dichavador Premium Metal', 45.00, 'Dichavador de metal com 4 partes, ideal para moagem perfeita', '', 10, true, 'dichavador'),
  ('BONG-001', 'Bong Vidro Premium', 120.00, 'Bong de vidro borossilicato de alta qualidade', '', 5, true, 'bong'),
  ('SEDA-001', 'Seda King Size', 8.00, 'Seda de papel natural, pacote com 32 folhas', '', 50, true, 'seda'),
  ('VAP-001', 'Vaporizador Portátil', 350.00, 'Vaporizador portátil com controle de temperatura', '', 3, true, 'vaporizador')
ON CONFLICT (sku) DO NOTHING;
